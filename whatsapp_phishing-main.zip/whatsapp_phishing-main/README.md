# whatsapp_phishing
create a phishing link by this tool , spy target camera
