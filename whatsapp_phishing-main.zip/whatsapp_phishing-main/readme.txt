these packges are required for this script
1 run this command in terminal: pip install opencv-python
pip install colorama
2 pip install os
3 pip install email
